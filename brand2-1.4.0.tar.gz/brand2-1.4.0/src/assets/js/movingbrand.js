// let nextButton = document.getElementById('next');
// let prevButton = document.getElementById('prev');
// let carousel = document.querySelector('.carousel');
// let listHTML = document.querySelector('.carousel .list');
// let seeMoreButtons = document.querySelectorAll('.seeMore');
// let backButton = document.getElementById('back');


//     nextButton.onclick = function(){
//         showSlider('next');
//     }


// prevButton.onclick = function(){
//     showSlider('prev');
// }
// let unAcceppClick;
// const showSlider = (type) => {
//     nextButton.style.pointerEvents = 'none';
//     prevButton.style.pointerEvents = 'none';

//     carousel.classList.remove('next', 'prev');
//     let items = document.querySelectorAll('.carousel .list .item');
//     if(type === 'next'){
//         listHTML.appendChild(items[0]);
//         carousel.classList.add('next');
//     }else{
//         listHTML.prepend(items[items.length - 1]);
//         carousel.classList.add('prev');
//     }
//     clearTimeout(unAcceppClick);
//     unAcceppClick = setTimeout(()=>{
//         nextButton.style.pointerEvents = 'auto';
//         prevButton.style.pointerEvents = 'auto';
//     }, 2000)
// }
// seeMoreButtons.forEach((button) => {
//     button.onclick = function(){
//         carousel.classList.remove('next', 'prev');
//         carousel.classList.add('showDetail');
//     }
// });
// backButton.onclick = function(){
//     carousel.classList.remove('showDetail');
// }


// let autoSlideInterval = setInterval(() => {
//     showSlider('next'); // التحرك إلى العنصر التالي
// }, 6000); // 5000 مللي ثانية = 5 ثواني
// const resetAutoSlide = () => {
//     clearInterval(autoSlideInterval); // إيقاف الحركة التلقائية السابقة
//     autoSlideInterval = setInterval(() => {
//         showSlider('next');
//     }, 7000); // بدء الحركة التلقائية من جديد بعد 5 ثواني
// }

document.querySelectorAll('.carousel').forEach((carousel) => {
    const nextButton = carousel.querySelector('#next');
    const prevButton = carousel.querySelector('#prev');
    const listHTML = carousel.querySelector('.list');
    const seeMoreButtons = carousel.querySelectorAll('.seeMore');
    const backButton = carousel.querySelector('#back');

    let unAcceppClick;

    const showSlider = (type) => {
        nextButton.style.pointerEvents = 'none';
        prevButton.style.pointerEvents = 'none';

        carousel.classList.remove('next', 'prev');
        let items = listHTML.querySelectorAll('.item');
        if (type === 'next') {
            listHTML.appendChild(items[0]);
            carousel.classList.add('next');
        } else {
            listHTML.prepend(items[items.length - 1]);
            carousel.classList.add('prev');
        }
        clearTimeout(unAcceppClick);
        unAcceppClick = setTimeout(() => {
            nextButton.style.pointerEvents = 'auto';
            prevButton.style.pointerEvents = 'auto';
        }, 2000);
    };

    if (nextButton) nextButton.onclick = () => showSlider('next');
    if (prevButton) prevButton.onclick = () => showSlider('prev');

    seeMoreButtons.forEach((button) => {
        button.onclick = function () {
            carousel.classList.remove('next', 'prev');
            carousel.classList.add('showDetail');
        };
    });

    if (backButton) {
        backButton.onclick = () => {
            carousel.classList.remove('showDetail');
        };
    }

    let autoSlideInterval = setInterval(() => {
        showSlider('next');
    }, 6000);

    const resetAutoSlide = () => {
        clearInterval(autoSlideInterval);
        autoSlideInterval = setInterval(() => {
            showSlider('next');
        }, 7000);
    };
});
