
// document.getElementById('demosMenu').addEventListener('change', function(e){
//     var dropdown = document.getElementById('demosMenu');
//     window.location.href = dropdown.options[dropdown.selectedIndex].getAttribute('id') + '.html';
// });
document.addEventListener('DOMContentLoaded', function () {
    var dropdown = document.getElementById('demosMenu');
    if (dropdown) {
      dropdown.addEventListener('change', function (e) {
        window.location.href = dropdown.options[dropdown.selectedIndex].getAttribute('id') + '.html';
      });
    } else {
      console.warn('العنصر #demosMenu غير موجود في الصفحة.');
    }
  });
  
