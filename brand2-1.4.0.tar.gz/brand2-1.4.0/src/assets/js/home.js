import "lite-youtube-embed";
import BasePage from "./base-page";
import Lightbox from "fslightbox";
window.fslightbox = Lightbox;

class Home extends BasePage {
  onReady() {
    this.initFeaturedTabs();
  }

  /**
   * used in views/components/home/featured-products-style*.twig
   */
  initFeaturedTabs() {
    app.all(".tab-trigger", (el) => {
      el.addEventListener("click", ({ currentTarget: btn }) => {
        let id = btn.dataset.componentId;
        // btn.setAttribute('fill', 'solid');
        app
          .toggleClassIf(
            `#${id} .tabs-wrapper>div`,
            "is-active opacity-0 translate-y-3",
            "inactive",
            (tab) => tab.id == btn.dataset.target
          )
          .toggleClassIf(
            `#${id} .tab-trigger`,
            "is-active",
            "inactive",
            (tabBtn) => tabBtn == btn
          );

        // fadeIn active tabe
        setTimeout(
          () =>
            app.toggleClassIf(
              `#${id} .tabs-wrapper>div`,
              "opacity-100 translate-y-0",
              "opacity-0 translate-y-3",
              (tab) => tab.id == btn.dataset.target
            ),
          100
        );
      });
    });
    document
      .querySelectorAll(".s-block-tabs")
      .forEach((block) => block.classList.add("tabs-initialized"));

    document
      .querySelectorAll(".app-inner")
      .forEach((blocks) => blocks.classList.add("fullpage"));
    if (document.querySelector(".fullpage")) {
      // أنشئ وسم <style> جديد
      console.log("jQuery version:", $.fn.jquery);

      const style = document.createElement("style");
      style.innerHTML = `
              #fp-nav ul li,.fp-slidesNav ul li {
    height: auto;
    width: auto;
    text-align: center;
    margin-right: 13px
}

#fp-nav ul li:hover a span,.fp-slidesNav ul li:hover a span {
    margin: 
}

#fp-nav ul li a span,.fp-slidesNav ul li a span {
    background: #fff;
    height: 10px;
    width: 10px;
    position: unset;
    display: inline-block;

}

#fp-nav ul li a.active span,#fp-nav ul li:hover a.active span,.fp-slidesNav ul li a.active span,.fp-slidesNav ul li:hover a.active span {
    margin-right: px;
    height: 18px;
    width: 18px
}
            `;
      // أضف وسم <style> إلى وسم <head>
      document.head.appendChild(style);
    }
  }
}
/*
const script = document.createElement("script");
script.src = "movingbrand.js";
script.type = "text/javascript";
document.head.appendChild(script);
*/
Home.initiateWhenReady(["index"]);
