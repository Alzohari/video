/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/assets/js/examples.js":
/*!***********************************!*\
  !*** ./src/assets/js/examples.js ***!
  \***********************************/
/***/ (() => {

eval("// document.getElementById('demosMenu').addEventListener('change', function(e){\n//     var dropdown = document.getElementById('demosMenu');\n//     window.location.href = dropdown.options[dropdown.selectedIndex].getAttribute('id') + '.html';\n// });\ndocument.addEventListener('DOMContentLoaded', function () {\n  var dropdown = document.getElementById('demosMenu');\n  if (dropdown) {\n    dropdown.addEventListener('change', function (e) {\n      window.location.href = dropdown.options[dropdown.selectedIndex].getAttribute('id') + '.html';\n    });\n  } else {\n    console.warn('العنصر #demosMenu غير موجود في الصفحة.');\n  }\n});\n\n//# sourceURL=webpack://theme-raed/./src/assets/js/examples.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/assets/js/examples.js"]();
/******/ 	
/******/ })()
;