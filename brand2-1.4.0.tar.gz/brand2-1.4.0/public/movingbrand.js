/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/assets/js/movingbrand.js":
/*!**************************************!*\
  !*** ./src/assets/js/movingbrand.js ***!
  \**************************************/
/***/ (() => {

eval("// let nextButton = document.getElementById('next');\n// let prevButton = document.getElementById('prev');\n// let carousel = document.querySelector('.carousel');\n// let listHTML = document.querySelector('.carousel .list');\n// let seeMoreButtons = document.querySelectorAll('.seeMore');\n// let backButton = document.getElementById('back');\n\n//     nextButton.onclick = function(){\n//         showSlider('next');\n//     }\n\n// prevButton.onclick = function(){\n//     showSlider('prev');\n// }\n// let unAcceppClick;\n// const showSlider = (type) => {\n//     nextButton.style.pointerEvents = 'none';\n//     prevButton.style.pointerEvents = 'none';\n\n//     carousel.classList.remove('next', 'prev');\n//     let items = document.querySelectorAll('.carousel .list .item');\n//     if(type === 'next'){\n//         listHTML.appendChild(items[0]);\n//         carousel.classList.add('next');\n//     }else{\n//         listHTML.prepend(items[items.length - 1]);\n//         carousel.classList.add('prev');\n//     }\n//     clearTimeout(unAcceppClick);\n//     unAcceppClick = setTimeout(()=>{\n//         nextButton.style.pointerEvents = 'auto';\n//         prevButton.style.pointerEvents = 'auto';\n//     }, 2000)\n// }\n// seeMoreButtons.forEach((button) => {\n//     button.onclick = function(){\n//         carousel.classList.remove('next', 'prev');\n//         carousel.classList.add('showDetail');\n//     }\n// });\n// backButton.onclick = function(){\n//     carousel.classList.remove('showDetail');\n// }\n\n// let autoSlideInterval = setInterval(() => {\n//     showSlider('next'); // التحرك إلى العنصر التالي\n// }, 6000); // 5000 مللي ثانية = 5 ثواني\n// const resetAutoSlide = () => {\n//     clearInterval(autoSlideInterval); // إيقاف الحركة التلقائية السابقة\n//     autoSlideInterval = setInterval(() => {\n//         showSlider('next');\n//     }, 7000); // بدء الحركة التلقائية من جديد بعد 5 ثواني\n// }\n\ndocument.querySelectorAll('.carousel').forEach(function (carousel) {\n  var nextButton = carousel.querySelector('#next');\n  var prevButton = carousel.querySelector('#prev');\n  var listHTML = carousel.querySelector('.list');\n  var seeMoreButtons = carousel.querySelectorAll('.seeMore');\n  var backButton = carousel.querySelector('#back');\n  var unAcceppClick;\n  var showSlider = function showSlider(type) {\n    nextButton.style.pointerEvents = 'none';\n    prevButton.style.pointerEvents = 'none';\n    carousel.classList.remove('next', 'prev');\n    var items = listHTML.querySelectorAll('.item');\n    if (type === 'next') {\n      listHTML.appendChild(items[0]);\n      carousel.classList.add('next');\n    } else {\n      listHTML.prepend(items[items.length - 1]);\n      carousel.classList.add('prev');\n    }\n    clearTimeout(unAcceppClick);\n    unAcceppClick = setTimeout(function () {\n      nextButton.style.pointerEvents = 'auto';\n      prevButton.style.pointerEvents = 'auto';\n    }, 2000);\n  };\n  if (nextButton) nextButton.onclick = function () {\n    return showSlider('next');\n  };\n  if (prevButton) prevButton.onclick = function () {\n    return showSlider('prev');\n  };\n  seeMoreButtons.forEach(function (button) {\n    button.onclick = function () {\n      carousel.classList.remove('next', 'prev');\n      carousel.classList.add('showDetail');\n    };\n  });\n  if (backButton) {\n    backButton.onclick = function () {\n      carousel.classList.remove('showDetail');\n    };\n  }\n  var autoSlideInterval = setInterval(function () {\n    showSlider('next');\n  }, 6000);\n  var resetAutoSlide = function resetAutoSlide() {\n    clearInterval(autoSlideInterval);\n    autoSlideInterval = setInterval(function () {\n      showSlider('next');\n    }, 7000);\n  };\n});\n\n//# sourceURL=webpack://theme-raed/./src/assets/js/movingbrand.js?");

/***/ }),

/***/ "./src/assets/styles/examples.scss":
/*!*****************************************!*\
  !*** ./src/assets/styles/examples.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://theme-raed/./src/assets/styles/examples.scss?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	__webpack_modules__["./src/assets/styles/examples.scss"](0, {}, __webpack_require__);
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/assets/js/movingbrand.js"](0, __webpack_exports__, __webpack_require__);
/******/ 	
/******/ })()
;