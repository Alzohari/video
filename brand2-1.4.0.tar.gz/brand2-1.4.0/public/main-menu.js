/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/assets/js/partials/main-menu.js":
/*!*********************************************!*\
  !*** ./src/assets/js/partials/main-menu.js ***!
  \*********************************************/
/***/ (() => {

eval("// class NavigationMenu extends HTMLElement {\n//     connectedCallback() {\n//         salla.onReady()\n//             .then(() => salla.lang.onLoaded())\n//             .then(() => {\n//                 this.menus = [];\n//                 this.displayAllText = salla.lang.get('blocks.home.display_all');\n\n//                 return salla.api.component.getMenus()\n//                 .then(({ data }) => {\n//                     this.menus = data;\n//                     return this.render()\n//                 }).catch((error) => salla.logger.error('salla-menu::Error fetching menus', error));\n//             });\n//     }\n\n//     /** \n//     * Check if the menu has children\n//     * @param {Object} menu\n//     * @returns {Boolean}\n//     */\n//     hasChildren(menu) {\n//         return menu?.children?.length > 0;\n//     }\n\n//     /**\n//     * Check if the menu has products\n//     * @param {Object} menu\n//     * @returns {Boolean}\n//     */\n//     hasProducts(menu) {\n//         return menu?.products?.length > 0;\n//     }\n\n//     /**\n//     * Get the classes for desktop menu\n//     * @param {Object} menu\n//     * @param {Boolean} isRootMenu\n//     * @returns {String}\n//     */\n//     getDesktopClasses(menu, isRootMenu) {\n//         return `!hidden ${isRootMenu ? 'root-level lg:!hidden' : 'relative'} ${menu.products ? ' mega-menu' : ''}\n//         ${this.hasChildren(menu) ? ' has-children' : ''}`\n//     }\n\n//     /**\n//     * Get the mobile menu\n//     * @param {Object} menu\n//     * @param {String} displayAllText\n//     * @returns {String}\n//     */\n//     getMobileMenu(menu, displayAllText) {\n//         const menuImage = menu.image ? `<img src=\"${menu.image}\" class=\"rounded-full\" width=\"48\" height=\"48\" alt=\"${menu.title}\" />` : '';\n\n//         return `\n//         <li class=\"hidden text-sm font-bold\" ${menu.attrs}>\n//             ${!this.hasChildren(menu) ? `\n//                 <a href=\"${menu.url}\" aria-label=\"${menu.title || 'category'}\" class=\"text-gray-500 ${menu.image ? '!py-3' : ''}\" ${menu.link_attrs}>\n//                     ${menuImage}\n//                     <span>${menu.title || ''}</span>\n//                 </a>` :\n//                 `\n//                 <span class=\"${menu.image ? '!py-3' : ''}\">\n//                     ${menuImage}\n//                     ${menu.title}\n//                 </span>\n//                 <ul>\n//                     <li class=\"text-sm font-bold\">\n//                         <a href=\"${menu.url}\" class=\"text-gray-500\">${displayAllText}</a>\n//                     </li>\n//                     ${menu.children.map((subMenu) => this.getMobileMenu(subMenu, displayAllText)).join('')}\n//                 </ul>\n//             `}\n//         </li>`;\n//     }\n\n//     /**\n//     * Get the desktop menu\n//     * @param {Object} menu\n//     * @param {Boolean} isRootMenu\n//     * @returns {String}\n//     */\n//     getDesktopMenu(menu, isRootMenu) {\n//         return `\n//         <li class=\" ${this.getDesktopClasses(menu, isRootMenu)}\" ${menu.attrs}>\n//             <a href=\"${menu.url}\" aria-label=\"${menu.title || 'category'}\" ${menu.link_attrs}>\n//                 <span>${menu.title}</span>\n//             </a>\n//             ${this.hasChildren(menu) ? `\n//                 <div class=\"sub-menu ${this.hasProducts(menu) ? 'w-full left-0 flex' : 'w-56'}\">\n//                     <ul class=\"${this.hasProducts(menu) ? 'w-56 shrink-0 m-8 rtl:ml-0 ltr:mr-0' : ''}\">\n//                         ${menu.children.map((subMenu) => this.getDesktopMenu(subMenu, false)).join('\\n')}\n//                     </ul>\n//                     ${this.hasProducts(menu) ? `\n//                     <salla-products-list\n//                     source=\"selected\"\n//                     shadow-on-hover\n//                     source-value=\"[${menu.products}]\" />` : ''}\n//                 </div>` : ''}\n//         </li>`;\n//     }\n\n//     /**\n//     * Get the menus\n//     * @returns {String}\n//     */\n//     getMenus() {\n//     return this.menus.map((menu) => `\n\n//         ${this.getMobileMenu(menu, this.displayAllText)}\n//     `).join('\\n');\n// }\n\n//     /**\n//     * Render the header menu\n//     */\n//     render() {\n//         this.innerHTML =  `\n//         <nav id=\"mobile-menu\" class=\"mobile-menu \">\n//             <ul class=\"main-menu\">\n//             ${this.getMenus()} \n//             </ul>\n//             <button class=\"btn--close-sm close-mobile-menu sicon-cancel lg:hidden\"></button>\n//         </nav>\n//        </button>`;\n//     }\n// }\n\n// customElements.define('custom-main-menu', NavigationMenu);\n\n//# sourceURL=webpack://theme-raed/./src/assets/js/partials/main-menu.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/assets/js/partials/main-menu.js"]();
/******/ 	
/******/ })()
;